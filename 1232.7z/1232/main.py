name="Anastasiia"
userName = "Anastasiia"
user_name = "Anastasiia"

# две разные пенеиенные
name = "Anastasiia"
Name = "Anastasiia"

name = "Anastasiia" # определение переменной name
print(name) # вывод значения переменной name на консоль

name = "Anastasiia" # переменной nama равна "Anastasiia"
print(name) # выводит: Anastasiia
name = "Nastya" # меняем значение на "Nastya"
print(name) # выводит: Nastya







myAge = 22
print("Возраст", myAge) # Возраст: 22

myCount = 76
print("Количество:", myCount) # Количество: 76

myNamberOne = 0b11
myNamberTwo = 0b1011
myNamberThee = 0b100001
print(myNamberOne)
print(myNamberTwo)
print(myNamberThee)

myNamberOne = 0o7
myNamberTwo























































myNamber=input()
print(myNumber)


myAge=input("Введите свой возраст")
print("Ваш возрасмт", myAge)